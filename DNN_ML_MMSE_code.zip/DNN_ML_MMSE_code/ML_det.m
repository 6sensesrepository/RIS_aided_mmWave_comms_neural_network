function output = ML_det(codebook, H, y)
HC = H*codebook;
n_sector = size(codebook,1);
M = size (y,2);
output =  zeros(n_sector*2,M); % Hard decisions
tic
for idx = 1:M
    dist_codeword = sum(abs(y(:,idx) - HC).^2);
    [~,IDX] = min(dist_codeword);
    %disp(codebook(:,IDX))
    output(:,idx)= [real(codebook(:,IDX));imag(codebook(:,IDX))];
end
toc
