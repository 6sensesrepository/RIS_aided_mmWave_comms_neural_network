clear all
close all
semilla = 1  %Paper: semilla = 1; XX
rng(semilla)

res_file = strcat('simulation_results',num2str(semilla),'.mat');


%% Parameters
Nr = 3; % Receptores
Nt = 64*64; % Transmisores
n_sector = 4; % numero efectivo de simbolos transmitidos
SNR = 1e3; % SNR en lineal

x = [1+1i, 1-1i, -1+1i, -1-1i];
codebook = permn(x, n_sector).';

num_promedios = 1; %number of detections to estimate BER curves.
max_epochs_near = 100; 
max_epochs_far = 100; 

%% Iterate distances
d_RIS_RX = logspace(1,4,150); %Paper: logspace(1,4,150); XX

%% Initialize with zeros
MMSE_near = zeros(size(d_RIS_RX));
MMSE_far = zeros(size(d_RIS_RX));
nn_MSE_near = zeros(size(d_RIS_RX));
nn_MSE_far = zeros(size(d_RIS_RX));
BER_MMSE_near=zeros(size(d_RIS_RX)); VER_MMSE_near=BER_MMSE_near;
BER_MMSE_far=zeros(size(d_RIS_RX)); VER_MMSE_far=BER_MMSE_far;
BER_NN_near=zeros(size(d_RIS_RX)); VER_NN_near=BER_NN_near;
BER_NN_far=zeros(size(d_RIS_RX)); VER_NN_far=BER_NN_far;
BER_ML_near = zeros(size(d_RIS_RX)); VER_ML_near =BER_ML_near ;
BER_ML_far = zeros(size(d_RIS_RX)); VER_ML_far = BER_ML_far;

MMSE_near_p = zeros(num_promedios, size(d_RIS_RX,2));
MMSE_far_p = zeros(num_promedios, size(d_RIS_RX,2));
nn_MSE_near_p = zeros(num_promedios, size(d_RIS_RX,2));
nn_MSE_far_p = zeros(num_promedios, size(d_RIS_RX,2));
BER_MMSE_near_p = zeros(num_promedios, size(d_RIS_RX,2)); VER_MMSE_near_p = BER_MMSE_near_p;
BER_MMSE_far_p = zeros(num_promedios, size(d_RIS_RX,2)); VER_MMSE_far_p = BER_MMSE_far_p;
BER_NN_near_p= zeros(num_promedios, size(d_RIS_RX,2)); VER_NN_near_p=BER_NN_near_p;
BER_NN_far_p= zeros(num_promedios, size(d_RIS_RX,2)); VER_NN_far_p = BER_NN_far_p;
BER_ML_near_p = zeros(num_promedios, size(d_RIS_RX,2)); VER_ML_near_p = BER_ML_near_p;
BER_ML_far_p = zeros(num_promedios, size(d_RIS_RX,2)); VER_ML_far_p = BER_ML_far_p;

%% Training and detection loop
for p = 1:num_promedios

    for k = 1:size(d_RIS_RX, 2)

        % Channel and Training/Test Dataset 
        disp("Distance: "+ d_RIS_RX(k))
        [H_far, H_near, H_near_sim, H_far_sim] = get_H(n_sector, d_RIS_RX(k)); % debe depender de n_sector, SNR
        M = 1e3;  % channel accesses for training and channel estimation
        s = sign(randn(n_sector, M)) + 1i*sign(randn(n_sector, M)); %QPSK: 1+1i*1,...
        n = 1/sqrt(SNR)*(randn(Nr, M) + 1i*randn(Nr,M)); %Gaussian Noise!!!
        y_near = H_near_sim*s + n;
        y_far = H_far_sim*s + n;

        % Channel estimation
        H_est_near = y_near*s'/(s*s');
        H_est_far = y_far*s'/(s*s');

        % Preprocessing for NN (including CSI to received samples)
        y_p_near = H_est_near'/(H_est_near*H_est_near' + 1/SNR*eye(size(H_est_near*H_est_near')))*y_near;
        y_p_far = H_est_far'/(H_est_far*H_est_far' + 1/SNR*eye(size(H_est_far*H_est_far')))*y_far;

        % NN
        net_near = fitnet([8,8], 'trainbr');
        net_near.trainParam.epochs = max_epochs_near;
        net_near.divideParam.trainRatio = 100/100;
        net_near.divideParam.valRatio = 0/100;
        net_near.divideParam.testRatio = 0/100;
        net_near.trainParam.showWindow = 0;
        net_near = train(net_near,[real(y_p_near); imag(y_p_near)],[real(s); imag(s)]);
        view(net_near)

        net_far = fitnet([8 8], 'trainbr');
        net_far.trainParam.epochs = max_epochs_far;
        net_far.divideParam.trainRatio = 100/100;
        net_far.divideParam.valRatio = 0/100;
        net_far.divideParam.testRatio = 0/100;
        net_far.trainParam.showWindow = 0;
        net_far = train(net_far,[real(y_p_far); imag(y_p_far)],[real(s); imag(s)]);

        % Generate new samples for detection
        M = 2e6;  % channel accesses for BER and MSE performance estimation. Paper: M = 2e6 XX
        Nbits = 2*M*n_sector;
        s = sign(randn(n_sector, M)) + 1i*sign(randn(n_sector, M)); %QPSK: 1+1i*1,...
        n = 1/sqrt(SNR)*(randn(Nr, M) + 1i*randn(Nr,M)); %Gaussian Noise!!!
        b_sent = [real(s);imag(s)];

        y_near = H_near_sim*s + n;
        y_p_near = H_est_near'/(H_est_near*H_est_near' + 1/SNR*eye(size(H_est_near*H_est_near')))*y_near;

        y_far = H_far_sim*s + n;
        y_p_far = H_est_far'/(H_est_far*H_est_far' + 1/SNR*eye(size(H_est_far*H_est_far')))*y_far;
        

        % MMSE Detection (near field)
        MMSE_near(k) = sum((abs(y_p_near - s)).^2, 'all')/(M*n_sector);
        output = sign([real(y_p_near); imag(y_p_near)]); % Hard decisions
        BER_MMSE_near(k) = sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_MMSE_near(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;

        % MMSE Detection (far field)
        MMSE_far(k) = sum((abs(y_p_far - s)).^2, 'all')/(M*n_sector);
        output = sign([real(y_p_far); imag(y_p_far)]); % Hard decisions
        BER_MMSE_far(k) = sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_MMSE_far(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;
        
        % NN Detection (near field)
        output = net_near([real(y_p_near); imag(y_p_near)]); % Soft decisions
        nn_MSE_near(k) = sum((abs(output - [real(s); imag(s)])).^2, 'all')/(M*n_sector);
        output = sign(output); % Hard decicions 
        BER_NN_near(k) =sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_NN_near(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;
        
        % NN Detection (far field)
        output = net_far([real(y_p_far); imag(y_p_far)]); % Soft decicions
        nn_MSE_far(k) = sum(abs((output - [real(s); imag(s)])).^2, 'all')/(M*n_sector);
        output = sign(output); %Hard decicions
        BER_NN_far(k) = sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_NN_far(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;

        % ML Detection (near field)
        output = ML_det(codebook, H_est_near, y_near);
        BER_ML_near(k) = sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_ML_near(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;
        
        % ML Detection (far field)
        output = ML_det(codebook, H_est_far, y_far);
        BER_ML_far(k) = sum(abs(b_sent-output)/2,'all')/Nbits;
        VER_ML_far(k) = sum(sum(abs(b_sent-output)/2,1)>0.5)/M;

        disp(datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss'))

    end

    MMSE_near_p(p, :) = MMSE_near;
    MMSE_far_p(p, :) = MMSE_far; 
    nn_MSE_near_p(p, :) =nn_MSE_near;
    nn_MSE_far_p(p, :) =nn_MSE_far;
    BER_ML_near_p(p,:) = BER_ML_near; VER_ML_near_p(p,:) = VER_ML_near;
    BER_ML_far_p(p,:) = BER_ML_far; VER_ML_far_p(p,:) = VER_ML_far;
    BER_MMSE_near_p(p,:) = BER_MMSE_near; VER_MMSE_near_p(p,:) = VER_MMSE_near;
    BER_MMSE_far_p(p,:) = BER_MMSE_far; VER_MMSE_far_p(p,:) = VER_MMSE_far;
    BER_NN_near_p(p,:) = BER_NN_near; VER_NN_near_p(p,:) = VER_NN_near;
    BER_NN_far_p(p,:) = BER_NN_far; VER_NN_far_p(p,:) = VER_NN_far;
    
end


%% Save the data
% Save data for each plot
data_MMSE = [d_RIS_RX', sum(MMSE_near_p,1)'/num_promedios, sum(MMSE_far_p,1)'/num_promedios];
data_nn_MSE = [d_RIS_RX', sum(nn_MSE_near_p,1)'/num_promedios, sum(nn_MSE_far_p,1)'/num_promedios];
data_MMSE_BER = [d_RIS_RX', sum(BER_MMSE_near_p,1)'/num_promedios, sum(BER_MMSE_far_p,1)'/num_promedios];
data_NN_BER = [d_RIS_RX', sum(BER_NN_near_p,1)'/num_promedios, sum(BER_NN_far_p,1)'/num_promedios]; 
data_ML_BER = [d_RIS_RX', sum(BER_ML_near_p,1)'/num_promedios, sum(BER_ML_far_p,1)'/num_promedios];
data_MMSE_VER = [d_RIS_RX', sum(VER_MMSE_near_p,1)'/num_promedios, sum(VER_MMSE_far_p,1)'/num_promedios];
data_NN_VER = [d_RIS_RX', sum(VER_NN_near_p,1)'/num_promedios, sum(VER_NN_far_p,1)'/num_promedios]; 
data_ML_VER = [d_RIS_RX', sum(VER_ML_near_p,1)'/num_promedios, sum(VER_ML_far_p,1)'/num_promedios];


% Save as MAT file
save(res_file, 'semilla','max_epochs_near', 'max_epochs_far', 'data_MMSE',  'data_nn_MSE', 'data_MMSE_BER','data_NN_BER', 'data_ML_BER','data_MMSE_VER','data_NN_VER', 'data_ML_VER');
disp("Simulation finished and results saved")

plot_results(res_file);