function plot_results(res_file)
load(res_file);
%Gráficas
close all
d = data_MMSE(:,1);

%%% MSE
figure;
% Create axes
axes1 = axes;
hold(axes1,'on');
plot(NaN,'bo-','LineWidth',1);
plot(NaN,'b-','LineWidth',1);
plot(NaN,'rv-','LineWidth',1);
plot(NaN,'r-.','LineWidth',1);

%MSE_NN
ynear = data_nn_MSE(:,2);
yfar = data_nn_MSE(:,3);
plot(d,yfar,'b','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'bo','LineWidth',2)
plot(d,ynear,'b','LineWidth',2)

% MMSE
ynear = data_MMSE(:,2);
yfar = data_MMSE(:,3);
plot(d,yfar,'r','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'rv','LineWidth',2)
plot(d,ynear,'r-.','LineWidth',2)

% Plot
grid
ht = title('NN and MMSE receivers','Interpreter','latex');
yt = ylabel('MSE','Interpreter','latex');
xt = xlabel('distance[m]','Interpreter','latex');
axis([10 1e4 1e-5 2.1])
l=legend('NN w/ FF simplification','NN w/o FF simplification','MMSE w FF simplification','MMSE w/o FF simplification','Interpreter','latex');
set(axes1,'FontSize',14,'XMinorTick','on','XScale','log','YMinorTick','on','YScale','linear');

%%%VER MSE, BER_NN, BER ML
figure;
% Create axes
axes1 = axes;
hold(axes1,'on');
plot(NaN,'bo-','LineWidth',1);
plot(NaN,'b-','LineWidth',1);
plot(NaN,'rv-','LineWidth',1);
plot(NaN,'r-.','LineWidth',1);
plot(NaN,'ks-','LineWidth',1);
plot(NaN,'k:','LineWidth',1);

%VER NN
ynear = data_NN_VER(:,2);
yfar = data_NN_VER(:,3);
plot(d,yfar,'b','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'bo','LineWidth',2)
plot(d,ynear,'b','LineWidth',2)

%BER MMSE
ynear = data_MMSE_VER(:,2);
yfar = data_MMSE_VER(:,3);
plot(d,yfar,'r','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'rv','LineWidth',2)
plot(d,ynear,'r-.','LineWidth',2)

%BER_ML
ynear = data_ML_VER(:,2);
yfar = data_ML_VER(:,3);
plot(d,yfar,'k','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'ks','LineWidth',2)
plot(d,ynear,'k:','LineWidth',2)

%Plot
grid
ht = title('NN, MMSE, and ML detection','Interpreter','latex');
yt = ylabel('VER','Interpreter','latex');
xt = xlabel('distance[m]','Interpreter','latex');
axis([10 1e4 1e-4 1.2])
l=legend('NN w/ FF simplification','NN w/o FF simplification','MMSE w FF simplification','MMSE w/o FF simplification','ML w/ FF simplification','ML w/o FF simplification','Interpreter','latex');
set(axes1,'FontSize',14,'XMinorTick','on','XScale','log','YMinorTick','on','YScale','log');



%%%BER MSE, BER_NN, BER ML
figure;
% Create axes
axes1 = axes;
hold(axes1,'on');
plot(NaN,'bo-','LineWidth',1);
plot(NaN,'b-','LineWidth',1);
plot(NaN,'rv-','LineWidth',1);
plot(NaN,'r-.','LineWidth',1);
plot(NaN,'ks-','LineWidth',1);
plot(NaN,'k:','LineWidth',1);

%BER NN
ynear = data_NN_BER(:,2);
yfar = data_NN_BER(:,3);
plot(d,yfar,'b','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'bo','LineWidth',2)
plot(d,ynear,'b','LineWidth',2)

%BER MMSE
ynear = data_MMSE_BER(:,2);
yfar = data_MMSE_BER(:,3);
plot(d,yfar,'r','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'rv','LineWidth',2)
plot(d,ynear,'r-.','LineWidth',2)

%BER_ML
ynear = data_ML_BER(:,2);
yfar = data_ML_BER(:,3);
plot(d,yfar,'k','LineWidth',2)
plot(d(1:10:end),yfar(1:10:end),'ks','LineWidth',2)
plot(d,ynear,'k:','LineWidth',2)

%Plot
grid
ht = title('NN, MMSE, and ML detection','Interpreter','latex');
yt = ylabel('BER','Interpreter','latex');
xt = xlabel('distance[m]','Interpreter','latex');
axis([10 1e4 1e-4 1.2])
l=legend('NN w/ FF simplification','NN w/o FF simplification','MMSE w FF simplification','MMSE w/o FF simplification','ML w/ FF simplification','ML w/o FF simplification','Interpreter','latex');
set(axes1,'FontSize',14,'XMinorTick','on','XScale','log','YMinorTick','on','YScale','log');

